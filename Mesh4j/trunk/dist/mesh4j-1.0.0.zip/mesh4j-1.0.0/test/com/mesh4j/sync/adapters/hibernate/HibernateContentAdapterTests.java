package com.mesh4j.sync.adapters.hibernate;

public class HibernateContentAdapterTests {

	// TODO (JMT) test
}
