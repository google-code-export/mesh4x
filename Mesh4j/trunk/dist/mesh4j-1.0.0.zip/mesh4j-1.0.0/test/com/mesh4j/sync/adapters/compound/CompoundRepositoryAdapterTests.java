package com.mesh4j.sync.adapters.compound;

public class CompoundRepositoryAdapterTests {
	// TODO (JMT) test
}
