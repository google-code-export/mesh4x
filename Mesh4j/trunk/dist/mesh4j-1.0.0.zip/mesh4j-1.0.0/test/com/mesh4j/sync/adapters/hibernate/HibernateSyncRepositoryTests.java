package com.mesh4j.sync.adapters.hibernate;

public class HibernateSyncRepositoryTests {

	// TODO (JMT) test
}
