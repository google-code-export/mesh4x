package com.mesh4j.sync.adapters.file;


public class SyncFileRepositoryTests {
	
	// TODO (JMT) test
	//repo.get(syncId);
	//repo.getAll(entityName);
	//repo.save(syncInfo);
}
