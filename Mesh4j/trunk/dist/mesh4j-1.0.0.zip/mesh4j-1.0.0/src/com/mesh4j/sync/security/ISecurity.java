package com.mesh4j.sync.security;

public interface ISecurity {

	String getAuthenticatedUser();

}
